import numpy as np
from PIL import Image, ImageDraw, ImageFont
import math

# ─── geometry on the 108 x 108 dp adaptive-icon canvas ───
C = 54.0          # centre
R = 24.0          # ring radius (centre of the stroke)
W = 7.5           # stroke width
CHECK = [(43.0, 55.0), (50.8, 62.8), (66.0, 45.8)]
GREEN = (0x3D, 0xDC, 0x84)
BG1 = (0x2B, 0x2B, 0x32)
BG2 = (0x0B, 0x0B, 0x0D)
SS = 4            # supersampling

def render(size, lo=18.0, hi=90.0, background=True, mono=False, guides=False):
    """Draws the icon. lo..hi = which part of the 108 dp canvas is shown (18..90 = what a launcher shows)."""
    N = size * SS
    k = N / (hi - lo)
    P = lambda x: (x - lo) * k
    img = Image.new("RGBA", (N, N), (0, 0, 0, 0))
    if background:
        ys, xs = np.mgrid[0:N, 0:N].astype(np.float32)
        t = ((xs / k + lo) + (ys / k + lo)) / 216.0          # same diagonal gradient as the vector drawable
        t = np.clip(t, 0, 1)[..., None]
        c1 = np.array(BG1, np.float32); c2 = np.array(BG2, np.float32)
        arr = (c1 * (1 - t) + c2 * t).astype(np.uint8)
        alpha = np.full((N, N, 1), 255, np.uint8)
        img = Image.fromarray(np.concatenate([arr, alpha], axis=2), "RGBA")

    def layer(): return Image.new("RGBA", (N, N), (0, 0, 0, 0))
    wpx = W * k
    ro = R + W / 2
    bbox = [P(C - ro), P(C - ro), P(C + ro), P(C + ro)]

    track = layer(); d = ImageDraw.Draw(track)
    track_col = (0, 0, 0, 89) if mono else (255, 255, 255, 41)
    d.ellipse(bbox, outline=track_col, width=int(round(wpx)))
    img = Image.alpha_composite(img, track)

    arc_col = (0, 0, 0, 255) if mono else GREEN + (255,)
    arc = layer(); d = ImageDraw.Draw(arc)
    d.arc(bbox, 270, 360, fill=arc_col, width=int(round(wpx)))
    d.arc(bbox, 0, 180, fill=arc_col, width=int(round(wpx)))
    for (x, y) in [(C, C - R), (C - R, C)]:                # round caps
        r = W / 2 * k
        d.ellipse([P(x) - r, P(y) - r, P(x) + r, P(y) + r], fill=arc_col)
    img = Image.alpha_composite(img, arc)

    chk = layer(); d = ImageDraw.Draw(chk)
    chk_col = (0, 0, 0, 255) if mono else (255, 255, 255, 255)
    pts = [(P(x), P(y)) for x, y in CHECK]
    d.line(pts, fill=chk_col, width=int(round(wpx)), joint="curve")
    for (x, y) in pts:
        r = W / 2 * k
        d.ellipse([x - r, y - r, x + r, y + r], fill=chk_col)
    img = Image.alpha_composite(img, chk)
    return img.resize((size, size), Image.LANCZOS)

def mask(shape, size):
    m = Image.new("L", (size * 4, size * 4), 0); d = ImageDraw.Draw(m); n = size * 4
    if shape == "circle":
        d.ellipse([0, 0, n - 1, n - 1], fill=255)
    elif shape == "square":
        d.rectangle([0, 0, n, n], fill=255)
    elif shape == "rounded":
        d.rounded_rectangle([0, 0, n - 1, n - 1], radius=int(n * 0.24), fill=255)
    elif shape == "squircle":            # Samsung-like superellipse
        pts = []
        for i in range(720):
            a = i / 720 * 2 * math.pi
            c, s = math.cos(a), math.sin(a)
            x = math.copysign(abs(c) ** (2 / 5), c); y = math.copysign(abs(s) ** (2 / 5), s)
            pts.append(((x + 1) / 2 * (n - 1), (y + 1) / 2 * (n - 1)))
        d.polygon(pts, fill=255)
    return m.resize((size, size), Image.LANCZOS)

def masked(img, shape):
    out = Image.new("RGBA", img.size, (0, 0, 0, 0))
    out.paste(img, (0, 0), mask(shape, img.size[0]))
    return out

# ─── PNG files ───
master = render(1024)
master.convert("RGB").save("png/icon-1024.png")                    # full square, no transparency (Play Store / any app list)
masked(master, "circle").save("png/icon-1024-round.png")           # round version for launchers that want a circle
masked(master, "squircle").save("png/icon-1024-squircle.png")      # Samsung-style
render(1024, 0, 108, background=False).save("png/foreground-layer-1024.png")   # transparent foreground (whole 108 dp canvas)
render(1024, 0, 108, background=True).convert("RGB").save("png/full-canvas-1024.png")
render(432, 0, 108, background=True).convert("RGB").save("png/full-canvas-432.png")

# preview sheet: how it looks in every mask
sheet = Image.new("RGB", (4 * 300 + 50, 2 * 300 + 60), (240, 240, 244))
shapes = [("circle", "Circle"), ("squircle", "Samsung squircle"), ("rounded", "Rounded square"), ("square", "Square")]
big = render(256)
small = render(64)
dr = ImageDraw.Draw(sheet)
for i, (sh, label) in enumerate(shapes):
    x = 10 + i * 310
    sheet.paste(masked(big, sh), (x + 20, 20), masked(big, sh))
    sheet.paste(masked(small, sh), (x + 110, 300), masked(small, sh))
    dr.text((x + 20, 285), label, fill=(60, 60, 70))
sheet2 = Image.new("RGB", sheet.size, (22, 22, 26))
for i, (sh, label) in enumerate(shapes):
    x = 10 + i * 310
    sheet2.paste(masked(big, sh), (x + 20, 20), masked(big, sh))
sheet.save("png/preview-light.png"); sheet2.save("png/preview-dark.png")

# guide image: shows the safe zone on the full 108 dp canvas
g = render(864, 0, 108).convert("RGB")
dg = ImageDraw.Draw(g)
k = 864 / 108
dg.rectangle([18 * k, 18 * k, 90 * k, 90 * k], outline=(255, 90, 90), width=3)                    # 72 dp visible area
dg.ellipse([(54 - 33) * k, (54 - 33) * k, (54 + 33) * k, (54 + 33) * k], outline=(255, 220, 80), width=3)   # 66 dp safe circle
dg.line([54 * k, 0, 54 * k, 864], fill=(120, 160, 255), width=1); dg.line([0, 54 * k, 864, 54 * k], fill=(120, 160, 255), width=1)
dg.text((24, 24), "red = visible 72 dp   yellow = safe zone 66 dp   blue = centre", fill=(255, 255, 255))
g.save("png/alignment-guides.png")
print("png ok")

# ─── SVG files ───
ring_track = f'M{C},{C-R} A{R},{R} 0 1,1 {C},{C+R} A{R},{R} 0 1,1 {C},{C-R} Z'
arc_path = f'M{C},{C-R} A{R},{R} 0 1,1 {C-R},{C}'
chk_path = 'M' + ' L'.join(f'{x},{y}' for x, y in CHECK)
def shapes_svg(track, arc, chk, tw):
    return (f'<path d="{ring_track}" fill="none" stroke="{track}" stroke-width="{W}"/>\n'
            f'  <path d="{arc_path}" fill="none" stroke="{arc}" stroke-width="{W}" stroke-linecap="round"/>\n'
            f'  <path d="{chk_path}" fill="none" stroke="{chk}" stroke-width="{W}" stroke-linecap="round" stroke-linejoin="round"/>')
grad = '<defs><linearGradient id="bg" gradientUnits="userSpaceOnUse" x1="0" y1="0" x2="108" y2="108"><stop offset="0" stop-color="#2B2B32"/><stop offset="1" stop-color="#0B0B0D"/></linearGradient></defs>'
open('svg/icon.svg', 'w').write(f'<svg xmlns="http://www.w3.org/2000/svg" width="1024" height="1024" viewBox="18 18 72 72">\n  {grad}\n  <rect x="0" y="0" width="108" height="108" fill="url(#bg)"/>\n  ' + shapes_svg('#FFFFFF" stroke-opacity="0.16', '#3DDC84', '#FFFFFF', 0) + '\n</svg>\n')
open('svg/foreground.svg', 'w').write('<svg xmlns="http://www.w3.org/2000/svg" width="1080" height="1080" viewBox="0 0 108 108">\n  ' + shapes_svg('#FFFFFF" stroke-opacity="0.16', '#3DDC84', '#FFFFFF', 0) + '\n</svg>\n')
open('svg/background.svg', 'w').write(f'<svg xmlns="http://www.w3.org/2000/svg" width="1080" height="1080" viewBox="0 0 108 108">\n  {grad}\n  <rect width="108" height="108" fill="url(#bg)"/>\n</svg>\n')
open('svg/monochrome.svg', 'w').write('<svg xmlns="http://www.w3.org/2000/svg" width="1080" height="1080" viewBox="0 0 108 108">\n  ' + shapes_svg('#000000" stroke-opacity="0.35', '#000000', '#000000', 0) + '\n</svg>\n')

# ─── Android resources ───
def vec(body, extra_ns=''):
    return f'<?xml version="1.0" encoding="utf-8"?>\n<vector xmlns:android="http://schemas.android.com/apk/res/android"{extra_ns}\n    android:width="108dp"\n    android:height="108dp"\n    android:viewportWidth="108"\n    android:viewportHeight="108">\n{body}</vector>\n'
def stroke(path, color, cap=True, join=False):
    return (f'    <path\n        android:fillColor="#00000000"\n        android:pathData="{path}"\n        android:strokeColor="{color}"\n        android:strokeWidth="{W}"'
            + ('\n        android:strokeLineCap="round"' if cap else '')
            + ('\n        android:strokeLineJoin="round"' if join else '') + ' />\n')
fg = stroke(ring_track, '#29FFFFFF', cap=False) + stroke(arc_path, '#FF3DDC84') + stroke(chk_path, '#FFFFFFFF', join=True)
mono = stroke(ring_track, '#59000000', cap=False) + stroke(arc_path, '#FF000000') + stroke(chk_path, '#FF000000', join=True)
open('android/res/drawable/ic_launcher_foreground.xml', 'w').write(vec(fg))
open('android/res/drawable/ic_launcher_monochrome.xml', 'w').write(vec(mono))
open('android/res/drawable/ic_launcher_background.xml', 'w').write(vec('''    <path android:pathData="M0,0h108v108h-108z">
        <aapt:attr name="android:fillColor">
            <gradient
                android:endX="108"
                android:endY="108"
                android:startX="0"
                android:startY="0"
                android:type="linear">
                <item android:color="#FF2B2B32" android:offset="0.0" />
                <item android:color="#FF0B0B0D" android:offset="1.0" />
            </gradient>
        </aapt:attr>
    </path>
''', extra_ns='\n    xmlns:aapt="http://schemas.android.com/aapt"'))
adaptive = '''<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@drawable/ic_launcher_background" />
    <foreground android:drawable="@drawable/ic_launcher_foreground" />
    <monochrome android:drawable="@drawable/ic_launcher_monochrome" />
</adaptive-icon>
'''
open('android/res/mipmap-anydpi-v26/ic_launcher.xml', 'w').write(adaptive)
open('android/res/mipmap-anydpi-v26/ic_launcher_round.xml', 'w').write(adaptive)
print('xml ok')
