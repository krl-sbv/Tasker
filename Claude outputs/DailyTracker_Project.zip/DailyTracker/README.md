# Tasker

A calm, private Android app for one question: **"Did I do what I planned today, and how am I doing over time?"**

Built with Kotlin and Jetpack Compose (Material 3). Package: `com.kirillshybaiev.dailytracker`. No accounts, no ads. The only network use is downloading holiday lists you ask for (see Holidays). Nothing else leaves your phone unless you export it.

---

## The idea behind the app

Most to-do apps are about *lists*. This one is about *consistency*. A list answers "what is left?". A tracker answers "am I the kind of person who keeps showing up?". The app started as a hand-drawn sketch of three screens (a calendar on the left, **today** in the middle, settings on the right) and a single goal: **track the progress of daily tasks, remind me at the right time, and show me honestly how I am doing.**

Principles that shaped every decision:

1. **Progress over perfection.** A day with nothing scheduled never breaks your streak. Skipping a day, pausing a habit for a trip, or dismissing an overdue task is a normal action and never counts as a failure. Everything that deletes or un-checks something has an **Undo**.
2. **One calm main screen.** *Today* shows your tasks and almost nothing else. Everything bigger (statistics, repeating-task management, settings) is one swipe or one tap away and is never forced on you.
3. **Honest, kind feedback.** The Insights screen tells you plainly when you are doing very well and when you need to get more disciplined, always with numbers behind it, and never more than four notes.
4. **Quiet design.** Monochrome (light, dark and true OLED black), edge-to-edge sheets, and colour only where it means something: green = done, red = missed, gray = partly. Your own task colours are the only decoration.
5. **Alive, not flashy.** Spring-physics motion (inspired by Android 16), a pill that appears only while you swipe, blur behind sheets. All of it can be switched to classic animations or off.
6. **Reminders that respect you.** Exact-time reminders with **Done** and **Snooze** buttons, an evening check-in at a slightly random time between 19:00 and 20:00 (so it doesn't feel robotic), and a weekly review. Each can be turned off.
7. **Your data is yours.** Everything is stored on the device. Finished tasks are kept forever, even after you delete the task. You can export, import and back up to a folder automatically.

---

## Screens

The app is one activity with three screens you swipe between. A small pill with the names **Calendar · Today · Profile** (the same look as the pill in Insights) appears while you swipe and hides again by itself. Tap a name to jump there. A first-start setup explains everything (see First start).

### Today (middle)
- Greeting, your **name** (tap to edit, the keyboard opens) and your **photo** (tap to pick one).
- A short quote that changes at midnight and at noon (60 quotes, can be switched off).
- Two thin lines: the time left **today**, and your **countdown**. Until you set one up the right-hand line says **Tap to set up**; tap it to open the Countdown screen (see below).
- The **Today** sheet with the date. Tap the header to open **Insights**.
- Your tasks in the order you added them. Tap the circle to check a task off, tap the row to edit it, **hold and drag to reorder**.
- Repeating tasks show their schedule and their own completion, e.g. `Every day · 100% completion (3/3)`.
- A slim red **"N overdue"** line appears only when a one-time task from an earlier day is still open. Open it to check tasks off late, or dismiss them.
- The **+** button (it does a little spin) adds a task.
- When the last task of the day is checked, a short **"Well done!"** style popup appears.

### Calendar (left)
- A month grid. Each day has a dot: **green** all done, **red** missed, **blue/gray** planned. Today is highlighted. You can start the week on **any weekday**.
- Public holidays: 10 countries are built in, any other country can be downloaded once and then works offline (see Holidays).
- The panel below switches between **Month** (one-time tasks and holidays of the month, default) and **Day** (everything on the selected day).
- In the Day view you can **check off forgotten tasks in the past** and **add a task on that date**.
- **Pull the lower panel up** (grab the bar or the title) to see more tasks of the month; push it down to get the grid back. Tapping a public holiday opens that day and shows the holiday name at the top.
- **Swipe the month** (title, weekdays and grid) left or right to change month; there are no arrow buttons. Swipe below the grid to switch screens. Tap the month title to jump back to today.

### Profile (right)
Your photo and name, then language and holidays, repeating tasks, appearance, notifications, calendar and data. See the table further down. In every section the rows you tap come first, then switches, then drop-down menus.

### Insights (tap the Today header)
A full-screen view you can also close with the back button or the edge-swipe. It has two swipeable pages and a pill at the bottom:
- **Overview**: completion rate, current streak, best streak of the last year, this week, a daily completion chart (7 / 30 / 90 days) and up to **four** written notes: an overall verdict, the trend against the previous period, your streak, and, if there is room, your most / least consistent task and your strongest / weakest weekday.
- **Per task** (repeating tasks only): pick a task and see its completion, streak, best streak, a 20-week **heatmap** and a note about when you tend to miss it.

Swipe in the **upper part** of Insights (title, chips, big numbers) to change between 7, 30 and 90 days. The graph has a **trend line** (moving average) and a label that says whether you are trending up or down. The **notes** are advice drawn from your data: too many tasks planned for what you finish, the task that slips most, whether reminders help, your weakest weekday, the change against the previous period and your streak. The pill (Overview / Per task) hides by itself.

### Repeating tasks (Profile)
Every repeating task listed once with its schedule, its next date and its completion, so a wrongly set schedule can be fixed immediately instead of waiting for the next occurrence.

---

## How tasks work

| Kind | Meaning |
|---|---|
| **One time** | Happens on one date. |
| **Every X days** | From a start date, every X days. 1 = every day, 2 = every other day, 7 = every week. Type any number up to 365. |
| **Weekdays** | Any combination, e.g. Mon + Wed + Fri. |

Every task can also have a **description**, a **reminder time** and a **colour** (8 presets or your own through a palette and hex code).

Editing a task offers big buttons for the things you need most:
- **Skip today** / **Pause until…** / **Resume**: skipped and paused days are ignored by streaks and percentages.
- **Stats**: opens the task's numbers and heatmap.
- **Move to today** / **Dismiss**: for overdue one-time tasks.
- Deleting a repeating task asks first and removes it from every day. Days you already finished stay in your history and export.

The schedule details (weekday circles or the X-days stepper) start folded when you edit; tap the repeat button once to show them and again to change the type.

### How the numbers are calculated
- **Day colour**: all scheduled tasks done = green; some done = gray; none done on a past day = red; today with nothing done yet is neutral.
- **Streak**: consecutive days where every scheduled task was done. Days with nothing scheduled are skipped, today does not break it until it is over, skipped / paused days are ignored. It looks back up to 365 days.
- **Task completion**: done days divided by scheduled days since the task started (today counts only once it is done).
- **Verdict**: 85 % or more "very well", 65 % or more "solid", 40 % or more "get more disciplined", below that "things aren't going well". The trend note triggers at a change of 5 points or more.

---

## Widgets

Four home-screen widgets, each with a preview in the widget picker. When you place one, a screen with a live preview asks for a background (**Light / Dark / Black / Transparent**), text colour (for transparent), **font size** (0.6× to 2.0×), **icon size** and widget-specific options. Black has no outline, so it blends into a black wallpaper. There is no blur background: Android does not let an app blur what is behind a widget, so the options are Light, Dark, Black and Transparent. Long-press a widget later to change its settings.

| Widget | What it shows |
|---|---|
| **Tasks · Today** | Big "Today" and the date, then today's tasks with coloured circles. Tap a task to check it off, tap the header to open the app. |
| **Tasks · Clock** | The same, with a big clock instead of "Today". The clock size is set in the widget's settings (40 to 120). |
| **Calendar · Month** | The current month: green = all done, gray = partly, red = missed, ring = today, and the streak count in the upper right corner. |
| **Insights · Heatmap** | A heatmap of 4 to 26 weeks for the **Overview** or for any one repeating task. |

---

## Notifications

- **Task reminder** at the time you set, with **Done** and **Snooze 10 min** buttons. It stays silent if the task is already done or skipped.
- **Evening nudge**: if tasks are left, a short list sometime between 19:00 and 20:00 (a different minute every day).
- **Weekly review** at the end of the week: your completion and how it compares to last week.
- Reminders are exact when you allow "Alarms & reminders" (Settings → Exact reminders opens the right page), and they survive a reboot.

---

## First start

Only the two permissions the app needs are asked, once: **notifications** and **exact reminders**. Nothing else. After that three short **tips** appear inside the app, on the Today screen: where to change your **name and photo**, how to **switch screens** (the pill shows up), and how to **open Insights** (tap the Today header). Language, holidays and backup are set later in Profile.

## Countdown

The right-hand stat on Today. Tap it to open the Countdown screen: count down to the **end of this week / month / year**, to **a date you pick** (with an optional **name**), or to the **end of your life**: **My life** takes your **birth date** and an **expected lifespan** (40 to 120 years) and shows how much of it has gone. **Show** switches between the time **left** and the time that has **elapsed** (since the start of the week / month / year, since the day you picked the date, or since birth). **Percent** shows the same as a percent. **Count in**: Default (under 24 h = hours and minutes, under 48 h = day and hours, under a year = days, longer = years and days), Hours, Days, Weeks, Months or Years. The thin bar always shows how much time has passed. Changes apply at once and the preview at the top updates.

## Languages

English, Español, Deutsch, Français, Italiano, Português, Polski, Русский, Українська and Türkçe (Latin and Cyrillic scripts only) are built in and work offline. "Device language" (pinned on top) follows the phone. Texts live in `app/src/main/assets/translations.tsv` (one line per English text, tab separated, columns in the order of `Lang.all`; to swap a language, change `Lang.all` and that column); a missing text shows in English. Not translated yet: the generated sentences in Insights and notifications, the quotes and holiday names.

## Holidays

Opened from Profile as its own screen: a search field, two pinned rows (**Automatic** = country of the phone, and **Installed only**), the **Installed** list (10 built-in countries: PL, DE, FR, CZ, ES, IT, GB, US, NL, BR, plus downloaded ones) and **All countries** with an **Install** button. Installing downloads last year, this year and the next two from the free Nager.Date service (only the country code and year are sent) and keeps them in the app's private storage, so they work offline. Not every country exists there; the app says so. Needs the `INTERNET` permission.

## Pausing a task

Pause until a date skips the task on every day **up to and including** that date; it is back the next day (the message after pausing says the day it returns). At midnight the app now refreshes its widgets and reminders by itself, and the Calendar and Insights screens move on to the new day, so a task that was paused through Thursday is there on Friday morning without opening the app first.

## Settings reference

| Section | Option |
|---|---|
| You | Name |
| Language & holidays | Language, Holidays (country screen), show holidays on/off |
| Tasks | Repeating tasks (review and fix schedules) |
| Appearance | Animations on/off, daily quote on/off, Theme (System / Light / Dark / Black), Swipe blur (Off / Light / Strong) |
| Notifications | Exact reminders, evening nudge on/off, weekly review on/off |
| Calendar | Week starts on |
| Data | Import, Export, Back up now, Reset all data, Auto-backup on/off |

**Swipe blur** is position based: while you drag, each screen is blurred by how far it is from the middle, so the one you leave gets blurrier and the one arriving gets sharper.

---

## Data and privacy

- All data lives in one JSON file in the app's private storage (`state.json`), written in the background and safely (temp file, then rename). Data of the first versions (SharedPreferences) is picked up automatically.
- Finished tasks are stored as **history** and kept forever. **Export all** writes tasks, history, skipped days, settings, your name and your photo to a JSON file you choose. **Import** merges a file into what you have (nothing is overwritten).
- **Auto-backup** keeps **one** file, `daily-tracker-backup.json`, in a folder you pick and overwrites it with the newest data (once a day, or on **Back up now**). The old one-file-per-day copies of earlier versions are removed the next time it runs.
- Uninstalling or clearing app data erases everything that was not exported or backed up.
- The only network use is downloading holiday lists you choose (see Holidays).

---

## Technical overview

```
Screens (Compose) ──► TrackerViewModel ──► Store (StateFlow, single source of truth) ──► state.json
                                              ▲
Notifications, reboot receiver, widgets ──────┘   (everything changes data through Store.update)
```

- **Kotlin + Jetpack Compose + Material 3**, one activity, no third-party libraries.
- **minSdk 26** (uses `java.time`). Blur needs Android 12+, the themed monochrome icon needs Android 13+. Everything else degrades gracefully.
- **State**: `Store` keeps an `AppState` in a `StateFlow`. The app, the notification buttons and the widgets all change data only through `Store.update`, so nothing overwrites anything else. Saving is coalesced and happens off the main thread.
- **Time rules** (`Models.kt`) are plain Kotlin functions: `occursOn`, `tasksOn`, `overdue`, `streak`, `taskStats`, `dayKind`. They are what the app, the notifications and the widgets share.
- **Alarms**: `AlarmManager` (exact when allowed, otherwise inexact), re-planned after reboot and whenever the app comes back.
- **Motion**: spring animations everywhere, switchable. The blur is applied in the draw phase, so animating it does not recompose the screen.
- **Widgets**: the two list widgets use `RemoteViews`, the calendar and heatmap widgets are drawn as bitmaps sized to the widget.
- **Start-up**: only the Today screen is built for the first frame, background work is moved off the main thread, and a baseline profile is included for release builds.

---

## Project structure

```
DailyTracker/
├─ README.md
├─ AndroidManifest.reference.xml        permissions, receivers, widgets, service (compare with yours)
├─ app/src/main/
│  ├─ assets/translations.tsv           texts of the 10 built-in languages
│  ├─ baseline-prof.txt                 start-up profile for release builds
│  ├─ java/com/kirillshybaiev/dailytracker/   Kotlin sources (27 files, below)
│  └─ res/
│     ├─ layout/    widget_tasks.xml, widget_item.xml, widget_image.xml
│     ├─ drawable/  ic_stat_check + ic_stat_snooze (notification icons), widget_bg, widget_ring, widget_dot, launcher icon layers
│     ├─ drawable-nodpi/ widget picker previews (4 PNG)
│     ├─ mipmap-anydpi-v26/   ic_launcher.xml, ic_launcher_round.xml (adaptive icon)
│     └─ xml/       tasks_widget_info, tasks_clock_widget_info, calendar_widget_info, insights_widget_info
└─ design/icon/                          app icon: PNG (1024 px), SVG, alignment guides, generator script
```

### Kotlin files

| File | What it does |
|---|---|
| `Backup.kt` | Automatic backup: one file in a folder you pick, overwritten with the newest data. |
| `BitmapWidgets.kt` | "Calendar · Month" and "Insights · Heatmap" widgets (drawn as pictures that fit the widget size). |
| `CalendarScreen.kt` | Calendar screen: month grid, Day / Month tabs, day list (check things off in the past, add a task for a date), holidays. |
| `ColorPicker.kt` | Custom colour dialog: palette, hue strip, hex code. |
| `Components.kt` | Shared UI pieces: root, sheet panel, auto-hiding swipe pill, tab pill, tab pill, swipe hint, avatar, name editor, chips, colour dots. |
| `Holidays.kt` | Public-holiday rules for 10 built-in countries plus downloadable offline packs for any other country. |
| `InsightsScreen.kt` | Insights: Overview page and Per-task page with the bottom tab pill, the analysis behind the written notes, charts. |
| `MainActivity.kt` | The activity and the app root: the 3 swipeable screens, full-screen overlays, task sheets, snackbars (Undo), "well done" popup, blur, first-time hints, photo / import / export / backup launchers. |
| `Menus.kt` | Pull-down menu button used everywhere. |
| `Models.kt` | Data model plus the rules: schedules, overdue, skips, streak, completion statistics. |
| `Motion.kt` | Spring animation helpers: press feedback, animated text swap, staggered appearance, buttons with feedback. |
| `Quotes.kt` | The 60 quotes of the main screen. |
| `Reminders.kt` | Alarms and notifications: task reminders (Done / Snooze), evening nudge, weekly review, reboot receiver. |
| `RepeatingScreen.kt` | List of every repeating task (shown once) to review and fix schedules. |
| `ProfileScreen.kt` | Profile screen (the former Settings): you, language & holidays, tasks, appearance, notifications, calendar, data; shared settings rows. |
| `PickerScreens.kt` | Language screen, Holidays screen (search, pinned rows, install), shared list rows. |
| `Onboarding.kt` | First-start setup and the two animated lessons. |
| `Countdown.kt` | The Today countdown (week / month / year / date, units, percent) and its setup screen. |
| `Strings.kt` | Language list, translation lookup `tx()`, locale handling. |
| `Store.kt` | Single source of truth + saving to a JSON file in the background (also reads data of older versions). |
| `TaskDetailScreen.kt` | Numbers, 20-week heatmap and notes of one task (used by Insights and by the Stats screen). |
| `TaskSheet.kt` | The add / edit task bottom sheet. |
| `TasksWidget.kt` | "Today" and "Clock" widgets, widget colours and per-widget settings, the list service. |
| `Theme.kt` | Light / dark / black colours and the animated colour scheme. |
| `TodayScreen.kt` | The Today screen: greeting, editable name, photo, quote, time-left bars, task list (overdue line, hold-and-drag reorder), add button, task rows. |
| `TrackerViewModel.kt` | Every action the screens can do (check, save, delete, reorder, skip, pause, settings...). |
| `WidgetConfigActivity.kt` | The screen shown when a widget is placed: live preview, background (incl. transparent and blur), text colour, font and icon size, clock size, weeks, what to show. |

---

## Install / build

1. Use (or create) an Android Studio project with package `com.kirillshybaiev.dailytracker`, Compose enabled, **minSdk 26**. No extra Gradle dependencies are needed.
2. Copy `app/src/main/java/com/kirillshybaiev/dailytracker/*.kt` into your package folder (replace the template `MainActivity.kt`).
3. Copy the files of `app/src/main/res/` and `app/src/main/baseline-prof.txt` into the same places of your project.
4. Open `AndroidManifest.xml` next to `AndroidManifest.reference.xml` and add the missing permissions, activity, receivers and service. Keep your own `<application>` attributes.
5. Optional: delete the old template launcher files (`mipmap-*/ic_launcher*.webp`), they are not used any more.
6. Sync, build, run. If a Gradle error says a library needs a newer `compileSdk`, lower that library's version (for example `core-ktx` to 1.16.0) in `gradle/libs.versions.toml`.

> **Status note:** the code was written and checked (syntax, brace balance, and the scheduling / statistics / holiday logic) without the Android toolchain. The first build on your machine is the real compile, so expect to fix a small typo or import here and there.

---

## App icon

An adaptive icon: a dark background, a progress ring in green and a white check mark, all inside the safe zone so it stays centred and uncropped on Samsung squircles, circles, rounded squares and plain squares. It also has a monochrome layer for themed icons (Android 13+).

- `design/icon/png/icon-1024.png`: 1024 × 1024 master (Play Store / anywhere a PNG is needed)
- `icon-1024-round.png`, `icon-1024-squircle.png`: pre-masked versions
- `foreground-layer-1024.png`, `full-canvas-1024.png`: layers for other tools
- `preview-light.png`, `preview-dark.png`, `alignment-guides.png`: how it looks in every mask and where the safe zone is
- `design/icon/svg/`: `icon.svg`, `foreground.svg`, `background.svg`, `monochrome.svg`
- `design/icon/generate_icon.py`: regenerates everything (Python + Pillow)

---

## Tips and troubleshooting

- **Slow start or swipe in Android Studio?** Debug builds are 2 to 3 times slower. Test a release build (`isMinifyEnabled = true`, `isShrinkResources = true`, debug signing config). Quick test without rebuilding: `adb shell cmd package compile -m speed -f com.kirillshybaiev.dailytracker`.
- **Swiping feels heavy?** Set Settings → Background blur to *Off*.
- **Reminders late or missing?** Allow "Alarms & reminders" (Settings → Exact reminders), allow notifications, and set the app's battery usage to *Unrestricted* on Samsung phones.
- **Widget does not show up?** Rebuild, remove it from the home screen and add it again.
- **Lost data after reinstall?** Use Export all or turn on Auto-backup, then Import.

---

## Limits and ideas for later

- English only; the holiday list covers 8 countries and can be extended by adding a rule function in `Holidays.kt`.
- No cloud sync and no tablet layout.
- Counter habits ("8 glasses of water") were deliberately left out to keep the app simple.
- A dedicated notification icon (the reminders currently use a system icon).
